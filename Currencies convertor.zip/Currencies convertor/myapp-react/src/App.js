
import './App.css';
import MainPage from './Components/MainPage';

function App() {
  return (
   <div>
    
    <MainPage/>
   </div>
  );
}

export default App;
