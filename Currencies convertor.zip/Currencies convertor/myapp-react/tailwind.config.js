/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      backgroundImage:{
        'cats': 'url("D:\MTboy\converter\myapp-react\pic\img.png")'
      }
    },
  },
  plugins: [],
}