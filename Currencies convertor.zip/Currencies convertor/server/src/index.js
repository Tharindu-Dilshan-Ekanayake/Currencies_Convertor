const express = require("express");
const cors = require("cors");
const axios = require("axios");

const app = express();

//middle wares setup font end and back end
app.use(express.json());
app.use(cors());

//all currences
app.get("/getAllCurrencies" , async (req, res)=>{
    const nameURL = "https://openexchangerates.org/api/currencies.json?app_id=952abb536b99436daccbf874c07050ac";
    
    
   
    try {
        const namesResponce = await axios.get(nameURL);
        const nameData = namesResponce.data;
        return res.json(nameData);

    
} catch (error) {
    console.error(error);
}
});

//get the target amount
app.get("/convert" ,async (req, res)=>{
   const {date,sourceCurrency, targetCurrency, amountInSourceCurrency} = req.query;
   try {
    // Format the date to 'YYYY-MM-DD'
    const formattedDate = date.replace(/(\d{4})(\d{2})(\d{2})/, "$1-$2-$3");

    // Construct the data URL with the formatted date
    const dataUrl = `https://openexchangerates.org/api/historical/${formattedDate}.json?app_id=952abb536b99436daccbf874c07050ac`;

    const dataResponce = await axios.get(dataUrl);
    const rates = dataResponce.data.rates;

    // Rate
    const sourceRate = rates[sourceCurrency];
    const targetRate = rates[targetCurrency];

    // Final target amount
    const targetAmount = (targetRate / sourceRate) * amountInSourceCurrency;

    return res.json(targetAmount.toFixed(2));
   } catch (error) {
    console.error(error);
    
   }
})

//listen to a port
app.listen(5000 , () => {
    console.log("SERVER STARTED");
});



